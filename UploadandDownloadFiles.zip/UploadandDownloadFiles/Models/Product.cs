﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UploadandDownloadFiles.Models
{
    public class Product
    {
        public string SN { get; set; }
        public string PAGE { get; set; }
        public string Suggestion { get; set; }
    }
}
